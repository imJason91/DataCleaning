import pandas as pd
import matplotlib.pyplot as plt

plt.rcParams['font.family'] = 'Microsoft JhengHei'

# 讀取房價數據
df = pd.read_csv("test_house_prices.csv")
df.head()

# 查看每一欄的null值數量
print(df.isnull().sum())

# 清理總價欄位，移除非數字的字串
df["總價"] = pd.to_numeric(df["總價"], errors="coerce")
# 補上值
df["總價"].fillna(df["總價"].median(), inplace=True)

# 移除重複的資料
df.drop_duplicates(inplace=True)

# 轉換格式
df["交易日期"] = pd.to_datetime(df["交易日期"], errors='coerce')
print(df["交易日期"].head())


# 顯示圖表
plt.hist(df["總價"], bins=50)
plt.xlabel("價格")
plt.ylabel("交易數量")
plt.show()

# remove 移除價位超過1億的建物
df = df[df["總價"]<100000000]

# 儲存清理過後的數據
df.to_csv("cleaned_house_prices.csv", index=False, encoding='utf-8-sig')